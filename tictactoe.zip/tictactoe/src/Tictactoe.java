package src;

import java.io.Console;
import src.utils.Board;

/**
* This is the main class of this tic tac toe game.
 *
 * <p>In this game of tic tac toe the user can decide the board size and the game adjusts to it.
 * The game also includes a simple AI that tries to block the player from winning and tries to
 * score a winning move. If the AI can't win or block player with next move it randomly puts its
 * down on the board.
 *@author Petri Irri
 *@version 2020.1211
 *@since JDK-15.0.1
 */

public class Tictactoe {

    /**
     * This is the main method of Tictactoe class
     *
     *@param args command line parameters. Not used.
     */
    public static void main(String [] args) {
        Console c = System.console();
        //create new board
        Board board = new Board();
        System.out.println("Made new board!");
        //Start gameplay loop which checks on each iteration if someone won. returns true if no wins.
        while(board.checkWin()) {
            //print board at the start of a new round
            board.printBoard();
            //ask user for their move and move them
            board.userMove();
            //make comuters move
            if(board.checkWin()){
                board.makeComputerMove();
            }
        }
        board.printBoard();
        //check who has won
        if(board.getWhoWon() == 1) {
            //player has won
            System.out.println("You have won!!!");
        } else if(board.getWhoWon() == 0) {
            //AI has won
            System.out.println("You have lost!!!\ndidn't know that was possible!?!!??");
        } else {
            //It was a draw!
            System.out.println("It was a draw!");
        }
    }
}
// End of file
