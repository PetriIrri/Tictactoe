package src.utils;

import java.io.Console;

/**
 * This class is responsible for creating the board and manipulating it. Also includes AI.
 *
 * <p>This class is used to create a board object which is then manipulated to play tic tac toe.
 * There are methods for: generating the board, printing the playing board, checking who won, checking if move is legal,
 * placing marker to the board, asking users move and generating computer move.
 *@author Petri Irri
 *@version 2020.1211
 *@since 15.0.1
 */

public class Board extends AskUser {
    /**
     *Stores the current state of the board.
     */
    private char[][] board;
    /**
     *Stores the amount of marks in a row needed to win.
     */
    private int marksToWin;
    /**
     *Stores the state of who has won. 1 = player, 0 = computer and 2 = draw.
     */
    private int whoWon;
    /**
     *Players marker
     */
    static final char playerMarker = 'X';
    /**
     *Computers marker
     */
    static final char aiMarker = 'O';


    /**
     * The constructor for Board object.
     *
     * <p>The constructor asks user for their preferred board size using AskUser class.
     * Then it generates and empty board with the given size and fills it with spaces.
     * The constructor also sets the amount of marks in a row needed to win. If the board
     * size bigger than 5 it uses n * 3 / 4 + 1 to calculate the amount of marks needed.
     * The calculation is not optimal for bigger board sizes.
     */
    public Board() {
        //ask the size of the board
        int n = askBoardSize();
        board = new char[n][n];
        //initialize the number of marks needed to win
        if(n <= 5) {
            marksToWin = n;
        } else {
            //this is not a good solution but it is good enough
            marksToWin = n * 3 / 4 + 1;
        }
        //fill board with spaces
        for(int i = 0; i < board.length; i++) {
            for(int j = 0; j < board[i].length; j++) {
                board[i][j] = ' ';
            }
        }
    }

    /**
     * Method  returns the value of private int whoWon.
     *
     * <p>Returns the integer of the state of whoWon. 1 = player won, 2 = a draw and 0 = computer won.
     *
     *@return return the state of who won.
     */
    public int getWhoWon() {
        //return the value of whoWon
        return whoWon;
    }

    /**
     * The method for printing the board.
     *
     * <p>Method looks thorugh every index of the boards 2d array and prints the value
     * within each index inside [] brackets.
     */
    public void printBoard() {
        for(int i = 0; i < board.length; i++) {
            for(int j = 0; j < board[i].length; j++) {
                System.out.print("[" + board[i][j] + "]");
            }
            System.out.println();
        }
    }

    /**
     * This method checks if someone has won.
     *
     * <p>The method uses other methods to check if anyone has won. The methods used are:
     * checkHorizontal(), checkVertical() and checkDiagonal().
     *
     *@return returns false if someone has won or if it is a draw. Otherwise returns true.
     */
    public boolean checkWin() {
        //Check horizontally, vertically and diagonally if there are three (enough marks to win) in a rows
        if(checkHorizontal() || checkVertical() || checkDiagonal() || boardFull())  {
            return false;
        }
        return true;
    }

    /**
     * This method checks if someone has won horizontally.
     *
     * <p>The method checks through the board horizontally and checks if anyone has won.
     * It calculates how many same marks it has read in a row and checks if they are enough for
     * a win. If someone won it stores the information in whoWon variable. 1 means player won
     * and 0 is for computer
     *
     *@return returns true if someone has won otherwise returns false.
     */
    public boolean checkHorizontal() {
        for(int i = 0; i < board.length; i++) {
            int aiMarks = 0;
            int playerMarks = 0;
            for(int j = 0; j < board[i].length; j++) {
                //if the index contains playerMarker ++ playermarks
                if(board[i][j] == playerMarker && playerMarks < marksToWin) {
                    playerMarks ++;
                    aiMarks = 0;
                } else if(board[i][j] == aiMarker && aiMarks < marksToWin) {
                    aiMarks ++;
                    playerMarks = 0;
                }
                //check if anyone has won and store who has won
                if(playerMarks >= marksToWin) {
                    //player has won
                    whoWon = 1;
                    return true;
                } else if(aiMarks >= marksToWin) {
                    //AI has won
                    whoWon = 0;
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * This method checks if someone has won vertically.
     *
     * <p>The method checks through the board vertically and checks if anyone has won.
     * It calculates how many same marks it has read in a vertical row and checks if they are enough for
     * a win. If someone won it stores the information in whoWon variable. 1 means player won
     * and 0 is for computer
     *
     *@return returns true if someone has won otherwise returns false.
     */
    public boolean checkVertical() {
        for(int i = 0; i < board.length; i++) {
            int aiMarks = 0;
            int playerMarks = 0;
            for(int j = 0; j < board[i].length; j++) {
                //if the index contains playerMarker ++ playermarks
                if(board[j][i] == playerMarker && playerMarks < marksToWin) {
                    playerMarks ++;
                    aiMarks = 0;
                } else if(board[j][i] == aiMarker && aiMarks < marksToWin) {
                    aiMarks ++;
                    playerMarks = 0;
                }
                //check if anyone has won and store who has won
                if(playerMarks >= marksToWin) {
                    //player has won
                    whoWon = 1;
                    return true;
                } else if(aiMarks >= marksToWin) {
                    //AI has won
                    whoWon = 0;
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * This method checks if someone has won diagonally.
     *
     * <p>The method checks through the board diagonally and checks if anyone has won.
     * It calculates how many same marks it has read in a diagonal row and checks if they are enough for
     * a win. If someone won it stores the information in whoWon variable. 1 means player won
     * and 0 is for computer
     *
     *@return returns true if someone has won otherwise returns false.
     */
    public boolean checkDiagonal() {
        //choose the starting index
        for(int i = 0; i < board.length; i++) {
            for(int j = 0; j < board.length; j++) {
                int aiMarks = 0;
                int playerMarks = 0;
                //store the starting index
                int row = i;
                int column = j;
                //check diagonally who has won.
                while(row < board.length && column < board.length) {
                    if(board[row][column] == playerMarker && playerMarks < marksToWin) {
                        playerMarks ++;
                        aiMarks = 0;
                    } else if(board[row][column] == aiMarker && aiMarks < marksToWin) {
                        aiMarks ++;
                        playerMarks = 0;
                    }
                    //check if anyone has won and store who has won
                    if(playerMarks >= marksToWin) {
                        //player has won
                        whoWon = 1;
                        return true;
                    } else if(aiMarks >= marksToWin) {
                        //AI has won
                        whoWon = 0;
                        return true;
                    }
                    //move to the next column and row diagonally
                    row ++;
                    column ++;
                }
            }
        }
        //chech mirrored diagonally
        for(int i = 0; i < board.length; i++) {
            for(int j = board.length - 1; j >= 0; j--) {
                int aiMarks = 0;
                int playerMarks = 0;
                //store the starting index
                int row = i;
                int column = j;
                //check diagonally who has won.
                while(row < board.length && column >= 0) {
                    if(board[row][column] == playerMarker && playerMarks < marksToWin) {
                        playerMarks ++;
                        aiMarks = 0;
                    } else if(board[row][column] == aiMarker && aiMarks < marksToWin) {
                        aiMarks ++;
                        playerMarks = 0;
                    }
                    //check if anyone has won and store who has won
                    if(playerMarks >= marksToWin) {
                        //player has won
                        whoWon = 1;
                        return true;
                    } else if(aiMarks >= marksToWin) {
                        //AI has won
                        whoWon = 0;
                        return true;
                    }
                    //move to the next column and row diagonally
                    row ++;
                    column --;
                }
            }
        }
        return false;
    }

    /**
     * This method checks if the board is full.
     *
     * <p>The method checks through the board and looks for empty spots. set whoWhon to 2 if the board is full
     *
     *@return returns false if en ampty spot is found otherwise return true as the board is full.
     */
    public boolean boardFull() {
        for(int i = 0; i < board.length; i++) {
            for(int j = 0; j < board[i].length; j++) {
                //if the spot is empty return false
                if(board[i][j] == ' ') {
                    return false;
                }
            }
        }
        //board is full!
        whoWon = 2;
        return true;
    }
    /**
     * This method places the users marker and uses askUserMove to ask where user wants to put their piece.
     *
     * <p> The method first asks the user their moves coordinates and then checks if the move is legal
     * using method moveIsLegal(). It continues asking the user for their move as long as the move is
     * illegal. When a legal move is inputted the method passes the coordinates to placemarker() which
     * places the users marker on the board.
     */
    public void userMove() {
        //ask users move and check if the move is legal AND NOT NEGATIVE
        int [] coord = askUserMove(playerMarker);
        while(!moveIsLegal(coord)) {
            System.out.println("Move is not legal!");
            coord = askUserMove(playerMarker);
        }
        //move was legal so place player marker on the board
        placeMarker(playerMarker, coord);
    }

    /**
     * This method checks if the users move is legal.
     *
     * <p> The method first checks if the given coordinates are on the board. Then it checks if the
     * given coordinates lead to an empty index.
     *
     *@param coord The coordinates to be checked if they are legal.
     *@return Returns the true if move is legal otherwise returns false.
     */
    public boolean moveIsLegal(int[] coord) {
        //check if the given are not negative and within the board
        if(coord[0] >= 0 && coord[1] >= 0 && coord[0] < board.length && coord[1] < board.length) {
            //check if the given coordinate is empty
            if(board[coord[0]][coord[1]] == ' ') {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * Places the given marker to the given coordinates.
     *
     *@param marker The given character to be placed into the board.
     *@param coord The coordinates to which we place the marker.
     */
    public void placeMarker(char marker, int[] coord) {
        board[coord[0]][coord[1]] = marker;
    }

    /**
     * This method decices the computers move.
     *
     * <p> the method first checks if it is possible for it to win on the next move.
     * If a win is possible it places a marker on the first available spot on the row.
     * Otherwise it checks if it can block the player from winning. It scans the board
     * and if it can block it places a marker on the first available spot on the row.
     * If it can neither win or block player, it places its marker randomly on the board.
     */
    public void makeComputerMove() {
        boolean madeMove = false;
        //Check if the computer can win
        //check horizontally
        for(int i = 0; i < board.length; i++) {
            int marks = 0;
            for(int j = 0; j < board[i].length; j++) {
                //if the index contains ai marker, ++ marks
                if(board[i][j] == aiMarker) {
                    marks ++;
                }
                //check if win is possible
                if(marks == marksToWin - 1) {
                    //win is possible
                    //place marker on first horizontal empty index
                    for(int s = 0; s < board[i].length; s++) {
                        //check if index is empty
                        if(board[i][s] == ' '  && !madeMove) {
                            int[] coord = {i, s};
                            //if move is legal: make the move
                            if(moveIsLegal(coord)) {
                                placeMarker(aiMarker, coord);
                                System.out.println("Computer made move!");
                                madeMove = true;
                            }
                        }
                    }
                }
            }
        }
        //check vertically
        if(!madeMove) {
            for(int i = 0; i < board.length; i++) {
                int marks = 0;
                for(int j = 0; j < board[i].length; j++) {
                    //if the index contains playerMarker ++ playermarks
                    if(board[j][i] == aiMarker) {
                        marks ++;
                    }
                    //check if win is possible
                    if(marks == marksToWin - 1) {
                        //win is possible
                        //place marker on first vertical empty index
                        for(int s = 0; s < board[i].length; s++) {
                            //check if index is empty
                            if(board[s][i] == ' '  && !madeMove) {
                                int[] coord = {s, i};
                                //if move is legal: make the move
                                if(moveIsLegal(coord)) {
                                    placeMarker(aiMarker, coord);
                                    System.out.println("Computer made move!");
                                    madeMove = true;
                                }
                            }
                        }
                    }
                }
            }
        }
        //check diagonally
        if(!madeMove) {
            //choose the starting index
            for(int i = 0; i < board.length; i++) {
                for(int j = 0; j < board.length; j++) {
                    int marks = 0;
                    //store the starting index
                    int row = i;
                    int column = j;
                    //check diagonally who has won.
                    while(row < board.length && column < board.length) {
                        if(board[row][column] == aiMarker) {
                            marks ++;
                        }
                        //check if win is possible
                        if(marks == marksToWin - 1) {
                            //win is possible
                            //place marker on first vertical empty index
                            int rowTemp = i;
                            int columnTemp = j;
                            //check diagonally who has won.
                            while(rowTemp < board.length && columnTemp < board.length) {
                                if(board[rowTemp][columnTemp] == ' ') {
                                    int[] coord = {rowTemp, columnTemp};
                                    //if move is legal: make the move
                                    if(moveIsLegal(coord)) {
                                        placeMarker(aiMarker, coord);
                                        System.out.println("Computer made move!");
                                        madeMove = true;
                                    }
                                }
                                rowTemp ++;
                                columnTemp ++;
                            }
                        }
                        //move to the next column and row diagonally
                        row ++;
                        column ++;
                    }
                }
            }
            //check mirrored diagonally
            for(int i = 0; i < board.length; i++) {
                for(int j = board.length - 1; j >= 0; j--) {
                    int marks = 0;
                    //store the starting index
                    int row = i;
                    int column = j;
                    //check diagonally who has won.
                    while(row < board.length && column >= 0) {
                        if(board[row][column] == aiMarker) {
                            marks ++;
                        }
                        //check if win is possible
                        if(marks == marksToWin - 1) {
                            //win is possible
                            //place marker on first diagonal empty index
                            int rowTemp = i;
                            int columnTemp = j;
                            //check diagonally who has won.
                            while(rowTemp < board.length && columnTemp >= 0) {
                                if(board[rowTemp][columnTemp] == ' ') {
                                    int[] coord = {rowTemp, columnTemp};
                                    //if move is legal: make the move
                                    if(moveIsLegal(coord)) {
                                        placeMarker(aiMarker, coord);
                                        System.out.println("Computer made move!");
                                        madeMove = true;
                                    }
                                }
                                rowTemp ++;
                                columnTemp --;
                            }
                        }
                        //move to the next column and row diagonally
                        row ++;
                        column --;
                    }
                }
            }
        }
        //CHECK FOR BLOCKS!
        //Chech for blocks horizontally
        if(!madeMove) {
            for(int i = 0; i < board.length; i++) {
                int marks = 0;
                for(int j = 0; j < board[i].length; j++) {
                    //if the index contains ai marker, ++ marks
                    if(board[i][j] == playerMarker) {
                        marks ++;
                    }
                    //check if win is possible
                    if(marks == marksToWin - 1) {
                        //win is possible
                        //place marker on first horizontal empty index
                        for(int s = 0; s < board[i].length; s++) {
                            //check if index is empty
                            if(board[i][s] == ' '  && !madeMove) {
                                int[] coord = {i, s};
                                //if move is legal: make the move
                                if(moveIsLegal(coord)) {
                                    placeMarker(aiMarker, coord);
                                    System.out.println("Computer made move!");
                                    madeMove = true;
                                }
                            }
                        }
                    }
                }
            }
        }
        //check for block vertically
        if(!madeMove) {
            for(int i = 0; i < board.length; i++) {
                int marks = 0;
                for(int j = 0; j < board[i].length; j++) {
                    //if the index contains playerMarker ++ playermarks
                    if(board[j][i] == playerMarker) {
                        marks ++;
                    }
                    //check if win is possible
                    if(marks == marksToWin - 1) {
                        //win is possible
                        //place marker on first vertical empty index
                        for(int s = 0; s < board[i].length; s++) {
                            //check if index is empty
                            if(board[s][i] == ' '  && !madeMove) {
                                int[] coord = {s, i};
                                //if move is legal: make the move
                                if(moveIsLegal(coord)) {
                                    placeMarker(aiMarker, coord);
                                    System.out.println("Computer made move!");
                                    madeMove = true;
                                }
                            }
                        }
                    }
                }
            }
        }
        //check for blocks diagonally
        if(!madeMove) {
            //choose the starting index
            for(int i = 0; i < board.length; i++) {
                for(int j = 0; j < board.length; j++) {
                    int marks = 0;
                    //store the starting index
                    int row = i;
                    int column = j;
                    //check diagonally who has won.
                    while(row < board.length && column < board.length) {
                        if(board[row][column] == playerMarker) {
                            marks ++;
                        }
                        //check if win is possible
                        if(marks == marksToWin - 1) {
                            //win is possible
                            //place marker on first vertical empty index
                            int rowTemp = i;
                            int columnTemp = j;
                            //check diagonally who has won.
                            while(rowTemp < board.length && columnTemp < board.length) {
                                if(board[rowTemp][columnTemp] == ' ') {
                                    int[] coord = {rowTemp, columnTemp};
                                    //if move is legal: make the move
                                    if(moveIsLegal(coord)) {
                                        placeMarker(aiMarker, coord);
                                        System.out.println("Computer made move!");
                                        madeMove = true;
                                    }
                                }
                                rowTemp ++;
                                columnTemp ++;
                            }
                        }
                        //move to the next column and row diagonally
                        row ++;
                        column ++;
                    }
                }
            }
            //check mirrored diagonally
            for(int i = 0; i < board.length; i++) {
                for(int j = board.length - 1; j >= 0; j--) {
                    int marks = 0;
                    //store the starting index
                    int row = i;
                    int column = j;
                    //check diagonally who has won.
                    while(row < board.length && column >= 0) {
                        if(board[row][column] == playerMarker) {
                            marks ++;
                        }
                        //check if win is possible
                        if(marks == marksToWin - 1) {
                            //win is possible
                            //place marker on first diagonal empty index
                            int rowTemp = i;
                            int columnTemp = j;
                            //check diagonally who has won.
                            while(rowTemp < board.length && columnTemp >= 0) {
                                if(board[rowTemp][columnTemp] == ' ') {
                                    int[] coord = {rowTemp, columnTemp};
                                    //if move is legal: make the move
                                    if(moveIsLegal(coord)) {
                                        placeMarker(aiMarker, coord);
                                        System.out.println("Computer made move!");
                                        madeMove = true;
                                    }
                                }
                                rowTemp ++;
                                columnTemp --;
                            }
                        }
                        //move to the next column and row diagonally
                        row ++;
                        column --;
                    }
                }
            }
        }
        //make random move if cannot block
        if(!madeMove) {
            //pick random row;
            while(!madeMove) {
                //generate random x and y coordinates
                int[] coord ={(int) (Math.random() * board.length), (int) (Math.random() * board.length)};
                if(moveIsLegal(coord)) {
                    placeMarker(aiMarker, coord);
                    System.out.println("Computer made move!");
                    madeMove = true;
                }
            }
        }
    }
}
// End of file
