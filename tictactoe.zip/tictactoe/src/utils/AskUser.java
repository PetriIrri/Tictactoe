package src.utils;

import java.io.Console;


/**
 * This class is used to ask user input and validating it.
 *
 * <p>There is a method for asking user the board size and validating that the size is
 * within given limit. There is also a method for asking the user where they would like to place their marker.
 *@author Petri Irri
 *@version 2020.1211
 *@since JDK-15.0.1
 */

public class AskUser {
    /**
     *Allows the use oc console with variable c
     */
    static final Console c = System.console();

    /**
     * This method asks the user for the coordinates in which to place their marker.
     *
     * <p>The coordinates user inputted are stored as 1 less than inputted to prevent confusion  on the
     * users end. This makes it so that users row 1 mathes an arrays first index.
     *
     *@param playerMarker Is used when asking user input to show what is the users marker.
     *@return return the coordinates which user has inputted.
     */
    public int[] askUserMove(char playerMarker) {
        //aks the user for their moves coordinates
        System.out.println("In what row would you like to place " + playerMarker + "?");
        int x = Integer.parseInt(c.readLine()) - 1;
        System.out.println("In what column would you like to place " + playerMarker + "?");
        int y = Integer.parseInt(c.readLine()) - 1;

        //return the user moves coordinates
        int[] array = {x, y};
        return array;
    }

    /**
     * This method asks the user for their preferred board size.
     *
     * <p>The method validates that the given size is at least 3. if the given size is smaller than 3
     * then the size is asked again and user is reminded that the minimium is 3.
     *
     *@return returns users given board size.
     */
    public int askBoardSize() {
        //ask user for board size
        int boardZise;
        System.out.println("The game board size is N*N. Please tell the board size by inputing the size of N.");
        do{
            boardZise = Integer.parseInt(c.readLine());
            if(boardZise < 3) {
                System.out.println("Minimium board size is 3!");
            }
        } while(boardZise < 3);//boardZise must be at least 3
        return boardZise;
    }
}
// End of file
