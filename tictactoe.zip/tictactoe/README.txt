AUTHOR
    PETRI IRRI
TO COMPILE AND RUN
    javac src/Tictactoe.java
    java src/Tictactoe
SCREENCAST OF THE PROJECT WORK
    https://youtu.be/ZD6RDYmS1Q8